CREATE --make New (POST)
RETRIEVE  --GET --(list/Search)
UPDATE -- Edit
DELETE --- Delete

List/ Search

For http method
CREATE --POST
RETRIEVE  --GET
UPDATE -- PUT/PATCH
DELETE --- DELETE

Most database webapp use the CRUD method check wikipedia for more details