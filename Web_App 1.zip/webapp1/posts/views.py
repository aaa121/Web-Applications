from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
#The views handle the request and the response.

def post_home(request): # The app works to send a request and get a response in return

    return HttpResponse("<h1>Hello</h1>\n<h2>Welcome to my World</h2>\n<a>http://www.google.com</a>")

def about(request):
    return HttpResponse("<div><div1><div2><div3>This website is for practice at the moment</div3></div2></div1></div>")

#THE CRUD method after using url configuration with in the app not app control
def create_post(request):
    return HttpResponse("<h1>Create</h1>")
def list_post(request):
    return HttpResponse("<h1>Details</h1>")
def update_post(request):
    return HttpResponse("<h1>Update</h1>")
def delete_post(request):
    return HttpResponse("<h1>Delete</h1>")

def home(request):
    return render(request,"index.html",{})