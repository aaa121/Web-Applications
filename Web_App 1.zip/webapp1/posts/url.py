from django.conf.urls import url
from django.contrib import admin
from posts import views
from .views import (post_home,
                    create_post,
                    delete_post,
                    update_post,
                    about,
                    home,
                    list_post)
urlpatterns = [
    url(r'^admin/', admin.site.urls),
    #url(r'^post/$', views.post_home),
    #url(r'^post/$', "posts.views.post_home", name="Home"), # Instead of importing, the relative path can be
    # stated in quotation. This method is better especially if views of another app is to imported
    url(r'^$', post_home),
    url(r'^about/$', about),
    url(r'^create/$', create_post),
    url(r'^list/$', list_post),
    url(r'^update/$', update_post),
    url(r'^delete/$', delete_post,name="Delete"),
    url(r'^home/$', home),

]